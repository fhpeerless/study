// 语文笔记数据
const pythonNotes = [
  {
    title: "python的安装",
    content: "python官网地址<a href=\"https://www.python.org/\">python</a>，百度找的安装教程，看一下教程学习！",
    timestamp: "2025-10-10 08:30",
    image: "https://picsum.photos/seed/love1/400/300",
    embed: '<iframe src="//player.bilibili.com/player.html?isOutside=true&aid=115341732611285&bvid=BV1FSx6zaETF&cid=32931515079&p=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe>'
  }
];


