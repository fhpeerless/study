// HTML第一章 多篇笔记（改为命名导出+数组汇总）
// 第一篇笔记
export const note1 = {
    title: "时态一般疑问句！",
    content: [
        "此笔记内容是上学时写的，总共有70多章，大约400多页，之后可能会出视频讲解，继续上传所有，如果学习上有问题请滑动到网页底部，加入QQ群聊共同探讨",
        "语法分析，句子纠错，可能需要登录（国内可用）<br> <a href=\"https://wordvice.ai/cn/proofreading\">语法分析</a>， <br>或用百度出的ai查询语法正确与否<br>--><a href=\"https://www.baidu.com/index.htm\">ai语法查询(文心一言)c</a>   <br>更多查询google（国外可用）--><a href=\"https://www.google.com/\">google</a>",

    ],
    timestamp: "2025-10-10 08:30",
    images: [
        "http://note.youdao.com/yws/api/personal/file/WEB1f1b8b1a3ddcc3f3ef698a5f8bc7c9f6?method=download&inline=true&shareKey=969f3d4830d0aac90daf21837b4b185e"
       

    ],
    embed: ""
};
// HTML第一章 多篇笔记（改为命名导出+数组汇总）
// 第一篇笔记
export const note2 = {
    title: "时态及一般疑问句的句子结构！",
    content: [
        "此笔记内容是上学时写的，总共有70多章，大约400多页，之后可能会出视频讲解，继续上传所有，如果学习上有问题请滑动到网页底部，加入QQ群聊共同探讨",
        "语法分析，句子纠错，可能需要登录（国内可用）<br> <a href=\"https://wordvice.ai/cn/proofreading\">语法分析</a>， <br>或用百度出的ai查询语法正确与否<br>--><a href=\"https://www.baidu.com/index.htm\">ai语法查询(文心一言)c</a>   <br>更多查询google（国外可用）--><a href=\"https://www.google.com/\">google</a>",

    ],
    timestamp: "2025-10-10 08:30",
    images: [  
        "http://note.youdao.com/yws/api/personal/file/WEB6a6c94676b91d0bd611fcd0a3628d05a?method=download&inline=true&shareKey=ad4f15b141d4a4776ad98b4526e38d4b",
        "http://note.youdao.com/yws/api/personal/file/WEBc3b7683be02a656e46b7f065a75dea55?method=download&inline=true&shareKey=eef201f3027b7b1b4c8cabd74d4c153e"
        
    ],
    embed: ""
};
// HTML第一章 多篇笔记（改为命名导出+数组汇总）
// 第一篇笔记
export const note3 = {
    title: "一般疑问句的造句示例！",
    content: [
        "此笔记内容是上学时写的，总共有70多章，大约400多页，之后可能会出视频讲解，继续上传所有，如果学习上有问题请滑动到网页底部，加入QQ群聊共同探讨",
        "语法分析，句子纠错，可能需要登录（国内可用）<br> <a href=\"https://wordvice.ai/cn/proofreading\">语法分析</a>， <br>或用百度出的ai查询语法正确与否<br>--><a href=\"https://www.baidu.com/index.htm\">ai语法查询(文心一言)c</a>   <br>更多查询google（国外可用）--><a href=\"https://www.google.com/\">google</a>",

    ],
    timestamp: "2025-10-10 08:30",
    images: [
       
        "http://note.youdao.com/yws/api/personal/file/WEBeaf35a45f0b043d4f84f57b5b10702f0?method=download&inline=true&shareKey=97e62c4f25fa0df0ab526f5abc127e93",
        "http://note.youdao.com/yws/api/personal/file/WEB42b4540760cb13a0a952fd0926b173a4?method=download&inline=true&shareKey=f6d3ee92899d795595adb62d2f091977"

    ],
    embed: ""
};


//export default [note1, note2, note3, note4, note5, note6, note7, note8, note9, note10, note11, note12];
export default [note1,note2,note3];




