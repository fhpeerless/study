// Python学科所有章节标题定义
export default [
    "H5jscss_学习路径",
    "论坛开发全掌握",
    "http由零入深",
    "python由零入深",
    "政治101研考学习方法",
    "c语言系列学习路径",
    "app开发学习路径"
];