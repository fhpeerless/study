import json
import random
import os
from datetime import datetime

def load_config(config_path):
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_config(config, config_path):
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=4)

def generate_password(config):
    chars = config.get('password_chars', ['w', 'a', 'n', 'g', 'd'])
    length = config.get('password_length', 6)
    
    password = ''.join(random.choice(chars) for _ in range(length))
    
    char_mapping = config.get('char_mapping', {'w': '1', 'a': '2', 'n': '3', 'g': '4', 'd': '5'})
    number = ''.join(char_mapping.get(c, c) for c in password)
    
    return password, number

def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    config_path = os.path.join(project_root, 'config', 'password_config.json')
    
    config = load_config(config_path)
    
    password, number = generate_password(config)
    
    config['current_password'] = password
    config['current_number'] = number
    config['last_updated'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    save_config(config, config_path)
    
    print(f"Generated password: {password} -> {number}")
    print(f"Updated at: {config['last_updated']}")

if __name__ == '__main__':
    main()
